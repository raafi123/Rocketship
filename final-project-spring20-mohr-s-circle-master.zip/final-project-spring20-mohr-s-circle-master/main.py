import pygame
import src.controller

def main():
	game = src.controller.Controller()
	game.mainloop()
    #Create an instance on your controller object
main()
